No installation needed.
Simply copy 4.txt to:
C:\Program Files (x86)\National Instruments\LabVIEW 201x\resource\PropertyPages
And copy PropPage_Decoration.vi to:
C:\Program Files (x86)\National Instruments\LabVIEW 201x\resource\PropertyPages\Pages

No need to restart LabVIEW.


George Zou
http://webspace.webring.com/people/og/gtoolbox

2016-07-05